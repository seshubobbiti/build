# Example projects to integrate Artifactory with Circle CI

## Projects for different package types:

* [Docker](circleci-docker-artifactory)
* [Maven](circleci-mvn-artifactory)
* [Npm](circleci-npm-artifactory)
* [Python](circleci-python-artifactory)
* [SBT](circleci-sbt-artifactory)
* [Generic](circleci-generic-artifactory)
