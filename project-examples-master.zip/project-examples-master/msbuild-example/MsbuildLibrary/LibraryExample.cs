﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MsbuildLibrary
{
    public class LibraryExample
    {
        public static string HelloWorld()
        {
            return "Hello world";
        }
    }
}
