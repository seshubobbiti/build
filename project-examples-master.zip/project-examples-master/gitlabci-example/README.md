# Example projects to integrate JFrog Artifactory with GitLab CI

## Projects for different package types:

* [Maven](gitlabci-maven-artifactory)
* [Gradle](gitlabci-gradle-artifactory)
* [Npm](gitlabci-npm-artifactory)
* [Docker](gitlabci-docker-artifactory)
