package artifactory.test;

/**
 * Hello world!
 */
public class Multi3 {
    public static void main(String[] args) {
        new Multi1();
        System.out.println("Hello World!");
    }
}
